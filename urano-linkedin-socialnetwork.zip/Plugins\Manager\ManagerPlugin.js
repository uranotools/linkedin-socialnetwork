"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Manager/ManagerPlugin.ts
var ManagerPlugin_exports = {};
__export(ManagerPlugin_exports, {
  ManagerPlugin: () => ManagerPlugin
});
module.exports = __toCommonJS(ManagerPlugin_exports);
var import_Vault = require("@core/Security/Vault");
var ManagerPlugin = class {
  configStore;
  constructor(moduleConfigCompiledByUrano) {
    this.configStore = moduleConfigCompiledByUrano;
  }
  getCredentials() {
    const token = import_Vault.Vault.getSecret("UranoLinkedInSocialNetwork", "LINKEDIN_ACCESS_TOKEN");
    const authorUrn = import_Vault.Vault.getSecret("UranoLinkedInSocialNetwork", "LINKEDIN_AUTHOR_URN");
    if (!token || !authorUrn) {
      throw new Error("Credenciales de LinkedIn (Access Token o Author URN) no configuradas en el Vault.");
    }
    return { token, authorUrn };
  }
  throwApiError(operation, errorResponse) {
    console.error(`Error en LinkedIn API [${operation}]:`, errorResponse);
    const detail = errorResponse ? JSON.stringify(errorResponse) : "Sin detalles adicionales";
    throw new Error(`Fallo en LinkedIn API (${operation}). Detalles t\xE9cnicos: ${detail}. Revisa tus argumentos o permisos de la app.`);
  }
  async executeAction(action, payload) {
    if (action === "apiPostText") return await this.apiPostText(payload);
    if (action === "apiPostArticle") return await this.apiPostArticle(payload);
    throw new Error(`Acci\xF3n ${action} no soportada en el ManagerPlugin de LinkedIn.`);
  }
  async makeRequest(payloadData, operationName) {
    const { token } = this.getCredentials();
    const response = await fetch("https://api.linkedin.com/v2/ugcPosts", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "X-Restli-Protocol-Version": "2.0.0",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payloadData)
    });
    if (!response.ok) {
      let errorData;
      try {
        errorData = await response.json();
      } catch (e) {
        errorData = { statusText: response.statusText, status: response.status };
      }
      this.throwApiError(operationName, errorData);
    }
    const data = await response.json();
    return data;
  }
  async apiPostText(payload) {
    const { content } = payload;
    if (!content || content.trim() === "") throw new Error("El contenido del post no puede estar vac\xEDo.");
    const { authorUrn } = this.getCredentials();
    console.log(`[UranoLinkedInSocialNetwork] Publicando texto: ${content.substring(0, 50)}...`);
    const requestBody = {
      author: authorUrn,
      lifecycleState: "PUBLISHED",
      specificContent: {
        "com.linkedin.ugc.ShareContent": {
          shareCommentary: { text: content },
          shareMediaCategory: "NONE"
        }
      },
      visibility: {
        "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
      }
    };
    const result = await this.makeRequest(requestBody, "postText");
    return {
      success: true,
      postId: result.id,
      message: "Post de texto publicado correctamente en LinkedIn."
    };
  }
  async apiPostArticle(payload) {
    const { content, articleUrl, articleTitle, articleDescription } = payload;
    if (!articleUrl || !articleTitle) throw new Error("Se requiere articleUrl y articleTitle.");
    const { authorUrn } = this.getCredentials();
    console.log(`[UranoLinkedInSocialNetwork] Publicando art\xEDculo: ${articleTitle}`);
    const mediaItem = {
      status: "READY",
      originalUrl: articleUrl,
      title: { text: articleTitle }
    };
    if (articleDescription) {
      mediaItem.description = { text: articleDescription };
    }
    const requestBody = {
      author: authorUrn,
      lifecycleState: "PUBLISHED",
      specificContent: {
        "com.linkedin.ugc.ShareContent": {
          shareCommentary: { text: content || "" },
          shareMediaCategory: "ARTICLE",
          media: [mediaItem]
        }
      },
      visibility: {
        "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"
      }
    };
    const result = await this.makeRequest(requestBody, "postArticle");
    return {
      success: true,
      postId: result.id,
      message: `Art\xEDculo '${articleTitle}' publicado correctamente en LinkedIn.`
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ManagerPlugin
});
