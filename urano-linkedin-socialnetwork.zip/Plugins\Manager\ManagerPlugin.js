"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// Plugins/Manager/ManagerPlugin.ts
var ManagerPlugin_exports = {};
__export(ManagerPlugin_exports, {
  ManagerPlugin: () => ManagerPlugin
});
module.exports = __toCommonJS(ManagerPlugin_exports);
var import_Vault = require("@core/Security/Vault");
var ManagerPlugin = class {
  configStore;
  constructor(moduleConfigCompiledByUrano) {
    this.configStore = moduleConfigCompiledByUrano;
  }
  getCredentials() {
    const token = import_Vault.Vault.getSecret("UranoLinkedInSocialNetwork", "LINKEDIN_ACCESS_TOKEN");
    const authorUrn = import_Vault.Vault.getSecret("UranoLinkedInSocialNetwork", "LINKEDIN_AUTHOR_URN");
    if (!token || !authorUrn) {
      throw new Error("Credenciales de LinkedIn (Access Token o Author URN) no configuradas en el Vault.");
    }
    return { token, authorUrn };
  }
  throwApiError(operation, errorResponse) {
    console.error(`Error en LinkedIn API [${operation}]:`, errorResponse);
    const errorMessage = errorResponse?.message || "Error desconocido";
    const serviceErrorCode = errorResponse?.serviceErrorCode ? ` (ServiceCode: ${errorResponse.serviceErrorCode})` : "";
    const status = errorResponse?.status ? `HTTP ${errorResponse.status}` : "HTTP Desconocido";
    const detail = errorResponse ? JSON.stringify(errorResponse) : "Sin detalles adicionales";
    let aiGuidance = "Revisa tus argumentos e intenta de nuevo.";
    if (errorResponse?.status === 401) {
      aiGuidance = "CR\xCDTICO: El token de acceso ha expirado o es inv\xE1lido. Notifica al usuario que debe generar un nuevo Token OAuth 2.0 en el Developer Portal de LinkedIn y guardarlo en el Vault de Urano.";
    } else if (errorResponse?.status === 403) {
      aiGuidance = "CR\xCDTICO: Problema de permisos. Notifica al usuario que el Token no tiene permisos de publicaci\xF3n (w_member_social / w_organization_social) o que el LINKEDIN_AUTHOR_URN ingresado es incorrecto y no tienes permisos para publicar a nombre de ese ID.";
    } else if (errorResponse?.status === 400) {
      aiGuidance = "Error de validaci\xF3n. Probablemente enviaste un JSON malformado o una URL inv\xE1lida. Revisa el esquema de tu petici\xF3n.";
    }
    throw new Error(`Fallo en LinkedIn API (${operation}) [${status}]. Mensaje: ${errorMessage}${serviceErrorCode}.

Instrucci\xF3n para la IA: ${aiGuidance}

Detalles JSON: ${detail}`);
  }
  async executeAction(action, payload) {
    if (action === "apiPostText") return await this.apiPostText(payload);
    if (action === "apiPostArticle") return await this.apiPostArticle(payload);
    throw new Error(`Acci\xF3n ${action} no soportada en el ManagerPlugin de LinkedIn.`);
  }
  async makeRequest(payloadData, operationName) {
    const { token } = this.getCredentials();
    const response = await fetch("https://api.linkedin.com/rest/posts", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "X-Restli-Protocol-Version": "2.0.0",
        "Linkedin-Version": "202604",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payloadData)
    });
    if (!response.ok) {
      let errorData;
      try {
        const textError = await response.text();
        errorData = textError ? JSON.parse(textError) : { statusText: response.statusText, status: response.status };
      } catch (e) {
        errorData = { statusText: response.statusText, status: response.status };
      }
      this.throwApiError(operationName, errorData);
    }
    const postId = response.headers.get("x-restli-id") || "Desconocido";
    let data = {};
    try {
      const text = await response.text();
      if (text) data = JSON.parse(text);
    } catch (e) {
    }
    return { ...data, id: postId };
  }
  async apiPostText(payload) {
    const { content } = payload;
    if (!content || content.trim() === "") throw new Error("El contenido del post no puede estar vac\xEDo.");
    let { authorUrn } = this.getCredentials();
    if (!authorUrn.startsWith("urn:li:")) {
      authorUrn = `urn:li:person:${authorUrn}`;
    }
    console.log(`[UranoLinkedInSocialNetwork] Publicando texto: ${content.substring(0, 50)}...`);
    const requestBody = {
      author: authorUrn,
      commentary: content,
      visibility: "PUBLIC",
      distribution: {
        feedDistribution: "MAIN_FEED",
        targetEntities: [],
        thirdPartyDistributionChannels: []
      },
      lifecycleState: "PUBLISHED",
      isReshareDisabledByAuthor: false
    };
    const result = await this.makeRequest(requestBody, "postText");
    return {
      success: true,
      postId: result?.id || "Desconocido",
      message: "Post de texto publicado correctamente en LinkedIn."
    };
  }
  async apiPostArticle(payload) {
    const { content, articleUrl, articleTitle, articleDescription } = payload;
    if (!articleUrl || !articleTitle) throw new Error("Se requiere articleUrl y articleTitle.");
    let { authorUrn } = this.getCredentials();
    if (!authorUrn.startsWith("urn:li:")) {
      authorUrn = `urn:li:person:${authorUrn}`;
    }
    console.log(`[UranoLinkedInSocialNetwork] Publicando art\xEDculo: ${articleTitle}`);
    const requestBody = {
      author: authorUrn,
      commentary: content || "",
      visibility: "PUBLIC",
      distribution: {
        feedDistribution: "MAIN_FEED",
        targetEntities: [],
        thirdPartyDistributionChannels: []
      },
      content: {
        article: {
          source: articleUrl,
          title: articleTitle,
          description: articleDescription || ""
        }
      },
      lifecycleState: "PUBLISHED",
      isReshareDisabledByAuthor: false
    };
    const result = await this.makeRequest(requestBody, "postArticle");
    return {
      success: true,
      postId: result?.id || "Desconocido",
      message: `Art\xEDculo '${articleTitle}' publicado correctamente en LinkedIn.`
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ManagerPlugin
});
