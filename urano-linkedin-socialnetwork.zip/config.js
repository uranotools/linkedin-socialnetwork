"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// config.ts
var config_exports = {};
__export(config_exports, {
  UranoLinkedInSocialNetworkConfig: () => UranoLinkedInSocialNetworkConfig
});
module.exports = __toCommonJS(config_exports);
var UranoLinkedInSocialNetworkConfig = {
  name: "UranoLinkedInSocialNetwork",
  description: "Gestor aut\xF3nomo de LinkedIn. Permite publicaci\xF3n de estados y art\xEDculos orientados a B2B y networking profesional.",
  icon: "Linkedin",
  // O "Briefcase"
  category: "Comunicaciones",
  enabledPlugins: ["Manager"],
  settings: [
    {
      name: "LINKEDIN_ACCESS_TOKEN",
      type: "password",
      title: "Access Token (OAuth 2.0)"
    },
    {
      name: "LINKEDIN_AUTHOR_URN",
      type: "password",
      title: "Author URN (ej: urn:li:person:12345 o urn:li:organization:67890)"
    },
    {
      name: "DEFAULT_POST_INTERVAL",
      type: "select",
      title: "Frecuencia recomendada de posts",
      options: [
        { label: "Cada 12 horas", value: "12h" },
        { label: "Diaria", value: "daily" },
        { label: "Semanal", value: "weekly" }
      ],
      default: "daily"
    }
  ],
  pluginSchemas: {
    Manager: {
      actions: {
        postText: {
          label: "\u{1F4DD} Publicar actualizaci\xF3n de texto",
          description: "Publica un post de texto en LinkedIn. \xDAtil para opiniones, reflexiones o anuncios cortos.",
          fields: [
            { name: "content", type: "prompt", label: "Contenido del post (usa un tono profesional)" }
          ]
        },
        postArticle: {
          label: "\u{1F517} Publicar art\xEDculo/enlace",
          description: "Publica un post que adjunta una tarjeta con un enlace a un art\xEDculo externo.",
          fields: [
            { name: "content", type: "prompt", label: "Tu comentario sobre el art\xEDculo" },
            { name: "articleUrl", type: "required", label: "URL absoluta del art\xEDculo" },
            { name: "articleTitle", type: "required", label: "T\xEDtulo corto del art\xEDculo" },
            { name: "articleDescription", type: "text", label: "Descripci\xF3n breve (opcional)" }
          ]
        }
      }
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  UranoLinkedInSocialNetworkConfig
});
